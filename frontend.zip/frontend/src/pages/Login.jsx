import API from "../services/api";
import { useState } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  async function loginRequestSent(e) {
    e.preventDefault();
    try {
      const response = await API.post("/auth/login", {
        email,
        password,
      });
      localStorage.setItem("token", response.data.token);
      toast.success("Logged In");
      navigate("/dashboard");
    } catch (err) {
      toast.success("Failure");
    }
  }
return (
  <div className="min-h-screen bg-gray-100 flex justify-center items-center">

    <div className="bg-white shadow-xl rounded-xl p-8 w-full max-w-md">

      <h1 className="text-3xl font-bold text-center text-blue-600 mb-2">
        APIShield
      </h1>

      <p className="text-center text-gray-500 mb-8">
        Welcome Back 👋
      </p>

      <form onSubmit={loginRequestSent} className="space-y-5">

        <div>
          <label className="block font-medium mb-2">
            Email
          </label>

          <input
            type="email"
            value={email}
            onChange={(e)=>setEmail(e.target.value)}
            className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block font-medium mb-2">
            Password
          </label>

          <input
            type="password"
            value={password}
            onChange={(e)=>setPassword(e.target.value)}
            className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg transition"
        >
          Login
        </button>

      </form>

      <p className="text-center text-gray-500 mt-6">
        Don't have an account?{" "}
        <Link
          to="/signup"
          className="text-blue-600 hover:underline"
        >
          Sign Up
        </Link>
      </p>

    </div>

  </div>
);
}
export default Login;

const User = require("../models/users");
const { setUser } = require("../service/auth");

async function signupUser(req, res) {
  const { name, email, password } = req.body;
  const user = await User.create({
    name,
    email,
    password,
  });
  return res.status(201).json({
    message: "User created",
  });
}
async function loginUser(req, res) {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if(!user) return res.status(401).json({ message:"Invalid credentials"});
    const isMatch = await user.matchPassword(password);
    if (isMatch) {
      const token = setUser(user);
      return res.json({
        token,
      });
    }
  } catch {
    return res.redirect("/login");
  }
}
function logoutUser() {
  return res.json({
    message: "Logout on client side",
  });
}
function getCurrentUser() {}

module.exports = {
  signupUser,
  loginUser,
  logoutUser,
  getCurrentUser,
};

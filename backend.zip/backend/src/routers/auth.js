const express = require("express");
const { restrictTo } = require("../middlewares/auth");
const {
  signupUser,
  loginUser,
  logoutUser,
  getCurrentUser,
} = require("../controllers/auth");

const router = express.Router();

router.post("/signup", signupUser);
router.post("/login", loginUser);
router.post("/logout", logoutUser);
router.get("/me", restrictTo("admin"), getCurrentUser);

module.exports = router;
